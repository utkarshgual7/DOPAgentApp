
import mv from "./mv.svg"
import play from "./play.svg";

import grid from "./grid.png";
import yourlogo from "./yourlogo.svg";
import searchMd from "./search-md.svg";
import plusSquare from "./plus-square.svg";
import sliders04 from "./sliders-04.svg";
import curve from "./hero/curve.png";
import robot from "./hero/robot.jpg";


export {
  mv,
  play,

  grid,
  yourlogo,
  searchMd,
  plusSquare,
  sliders04,

  curve,
  robot,
 
};
